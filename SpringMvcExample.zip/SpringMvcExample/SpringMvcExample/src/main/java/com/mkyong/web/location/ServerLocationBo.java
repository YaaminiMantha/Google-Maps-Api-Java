package com.mkyong.web.location;

public interface ServerLocationBo {

	ServerLocation getLocation(String address);

}