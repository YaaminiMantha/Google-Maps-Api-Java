package com.mykong.web.location;

import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.mkyong.web.location.ServerLocation;
import com.mkyong.web.location.ServerLocationBoImpl;

public class ServerLocationBoImplTest {
	
	@Test
    public void testGetLocation() throws IOException {
		ServerLocationBoImpl impl = new ServerLocationBoImpl();
		ServerLocation location = impl.getLocation("7668 Frederiksen Ln, Dublin CA 94568");
		Assert.assertNotNull(location);
		Assert.assertTrue(location.getLatitude().contains("37.7165"));
 
    }

}
